def hello_slopy():
    print("hello slopy")